@extends('reseller.layouts.reseller')

@section('content')

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- /.col -->
                <div class="col-md-12">
                    <div class="card card-primary card-outline ">
                        <div class="card-body">
                            <div class="btn-group">
                            </div>
                            <a href="{{ url()->previous() }}" class="btn btn-warning float-right"><i class="fa fa-reply"></i></a>
                        </div>
                    </div>

                    <div class="card card-info card-outline">
                    <!-- /.card-header -->
                        <div class="card-body">
                            <div id="settings">
                                <div class="tab-content">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <form action="{{ route('reseller.users.store') }}" class="client-form" method="POST">
                                                @csrf
                                                <input type="hidden" name="reseller_id" value="{{ $_auth->id }}">

                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="first_name" class="control-label">
                                                                <span class="req text-danger">* {{ __('lang.' . strtoupper('first_name')) }}</span>
                                                            </label>
                                                            <input type="text" name="first_name" class="form-control @error('first_name') is-invalid @enderror" value="{{ old('first_name') }}" required>
                                                            @error('first_name')
                                                            <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                            @enderror
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="last_name" class="control-label">
                                                                <span class="req text-danger">* {{ __('lang.' . strtoupper('last_name')) }}</span>
                                                            </label>
                                                            <input type="text" id="last_name" name="last_name" class="form-control @error('last_name') is-invalid @enderror" value="{{ old('last_name') }}" required>
                                                            @error('last_name')
                                                            <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                            @enderror
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="national_id" class="control-label">
                                                                <span class="req text-danger">* {{ __('lang.' . strtoupper('national_id')) }}</span>
                                                            </label>
                                                            <input type="text" id="national_id" name="national_id" class="form-control @error('national_id') is-invalid @enderror" value="{{ old('national_id') }}" required>
                                                            @error('national_id')
                                                            <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                            @enderror
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="email" class="control-label">
                                                                <span class="req text-danger">* {{ __('lang.' . strtoupper('email')) }}</span>
                                                            </label>
                                                            <input type="email" id="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" required>
                                                            @error('email')
                                                            <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                            @enderror
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="mobile" class="control-label">
                                                                <span class="req text-danger">* {{ __('lang.' . strtoupper('Mobile')) }}</span>
                                                            </label>
                                                            <input type="text" id="mobile" name="mobile" class="form-control @error('mobile') is-invalid @enderror" value="{{ old('mobile') }}" required>
                                                            @error('mobile')
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong>{{ $message }}</strong>
                                                            </span>
                                                            @enderror
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="phone" class="control-label">{{ __('lang.' . strtoupper('Phone')) }}</label>
                                                            <input type="text" id="phone" name="phone" class="form-control @error('phone') is-invalid @enderror" value="{{ old('phone') }}">
                                                            @error('phone')
                                                            <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                            @enderror
                                                        </div>
                                                    </div>

                                                </div>

                                                <div class="row">
                                                    <div class="col-12">
                                                        <a href="#" class="btn btn-secondary">{{ __('lang.' . strtoupper('Cancel')) }}</a>
                                                        <button type="submit" class="btn btn-success float-right add-payment-item">{{ __('lang.' . strtoupper('Submit')) }}</button>
                                                    </div>
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

@endsection
