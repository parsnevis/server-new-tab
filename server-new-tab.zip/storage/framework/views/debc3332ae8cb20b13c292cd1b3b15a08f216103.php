<div class="row">
    <div class="col-sm-12">
        <table class="widefat table table-striped text-center table-clients no-footer">
            <thead>
            <tr>
                <th class="id"><?php echo e(__('lang.' . strtoupper('#'))); ?></th>
                <th class="name"><?php echo e(__('lang.' . strtoupper('name'))); ?></th>
                <th class="email"><?php echo e(__('lang.' . strtoupper('email'))); ?></th>
                <th class="phone"><?php echo e(__('lang.' . strtoupper('mobile'))); ?></th>
                <th class="phone"><?php echo e(__('lang.' . strtoupper('phone_number'))); ?></th>
                <th class="phone"><?php echo e(__('lang.' . strtoupper('activated'))); ?></th>
                <th class="operation"><?php echo e(__('lang.' . strtoupper('operations'))); ?></th>
            </tr>
            </thead>

            <tbody>
            <?php if($users && count($users) > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><span class="persian-number"><?php echo e(($key+1)+($page == 1 ? 0 : ($page-1)*15)); ?></span></td>
                        <td>
                            <a href="<?php echo e(route('reseller.users.edit', $user->id)); ?>"><strong><?php echo e($user->first_name . ' ' . $user->last_name); ?></strong></a>
                        </td>
                        <td class="email"><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
                        <td><?php echo e($user->mobile); ?></td>
                        <td><?php echo e($user->phone_number); ?></td>
                        <td>
                            <div class="onoffswitch">
                                <input type="checkbox" name="user_status" class="onoffswitch-checkbox" id="user-<?php echo e($user->id); ?>" <?php echo e($user->activated_at != null ? 'checked' : ''); ?>>
                                <label class="onoffswitch-label" for="customer-<?php echo e($user->id); ?>"></label>
                            </div>
                        </td>

                        <td>
                            <div>
                                <form action="<?php echo e(route('reseller.users.destroy',$user->id)); ?>" method="POST">
                                    <div class="btn-group">

                                            <a href="<?php echo e(route('reseller.users.edit', $user->id)); ?>" class="btn btn-info"><i class="fas fa-edit"></i></a>



                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('آیا از حذف این آیتم مطمئن هستید؟');" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>

                                    </div>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>

            <tfoot>
            <tr>
                <th class="id"><?php echo e(__('lang.' . strtoupper('#'))); ?></th>
                <th class="name"><?php echo e(__('lang.' . strtoupper('name'))); ?></th>
                <th class="email"><?php echo e(__('lang.' . strtoupper('email'))); ?></th>
                <th class="phone"><?php echo e(__('lang.' . strtoupper('mobile'))); ?></th>
                <th class="phone"><?php echo e(__('lang.' . strtoupper('phone_number'))); ?></th>
                <th class="phone"><?php echo e(__('lang.' . strtoupper('activated'))); ?></th>
                <th class="operation"><?php echo e(__('lang.' . strtoupper('operations'))); ?></th>
            </tr>
            </tfoot>
        </table>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php /**PATH D:\laragon\www\server-new-tab\resources\views/reseller/users/data_table.blade.php ENDPATH**/ ?>