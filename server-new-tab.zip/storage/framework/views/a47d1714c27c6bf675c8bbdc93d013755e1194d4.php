<?php $__env->startSection('content'); ?>
    <?php $user_addresses = $user->addresses->where('status', 'Primary')->first(); //dd($user_addresses); ?>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">

                    <div class="card card-primary card-outline ">
                        <div class="card-body">
                            <div class="btn-group">
                            </div>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-warning float-right"><i class="fa fa-reply"></i></a>
                        </div>
                    </div>

                    <div class="card card-info card-outline user_information <?php echo e(((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == 'user_information') || Session::get('level') == 'user_information') ? '' : ((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == '') && Session::get('level') == '' ? '' : 'collapsed-card')); ?>">
                        <div class="card-header" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <h3 class="card-title"><?php echo e(__('lang.' . strtoupper('user_information'))); ?></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                                    <i class="fas fa-angle-double-<?php echo e(((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == 'user_information') || Session::get('level') == 'user_information') ? 'up' : ((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == '') && Session::get('level') == '' ? 'up' : 'down')); ?>"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" class="client-form" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>

                                        <input type="hidden" name="address_id" value="<?php echo e($user_addresses->id); ?>">
                                        <input type="hidden" name="form_level" value="user_information">

                                        <div class="row">

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="marketer_id" class="control-label">
                                                        <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('Marketer'))); ?></span>
                                                    </label>
                                                    <select name="marketer_id" class="selectpicker <?php $__errorArgs = ['marketer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-width="100%" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" required>
                                                        <option value="0"><?php echo e(__('lang.' . strtoupper('no_marketer'))); ?></option>
                                                        <?php $__currentLoopData = $marketers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($marketer->id); ?>" <?php echo e($marketer->id == $user->marketer_id ? 'selected' : ''); ?>><?php echo e($marketer->first_name . ' ' . $marketer->last_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('marketer_id')): ?>
                                                        <span class="help-block text-danger text-bold" role="alert">
                                                        <?php echo e($errors->first('marketer_id')); ?>

                                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>




































                                        </div>
                                        <hr class="bg-info">

                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="first_name" class="control-label">
                                                        <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('first_name'))); ?></span>
                                                    </label>
                                                    <input type="text" name="first_name" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->first_name); ?>" required>
                                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="last_name" class="control-label">
                                                        <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('last_name'))); ?></span>
                                                    </label>
                                                    <input type="text" name="last_name" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->last_name); ?>" required>
                                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="email" class="control-label">
                                                        <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('email'))); ?></span>
                                                    </label>
                                                    <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->email); ?>" required>
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="mobile" class="control-label">
                                                        <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('Mobile'))); ?></span>
                                                    </label>
                                                    <input type="text" name="mobile" class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->mobile); ?>" required>
                                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="phone" class="control-label"><?php echo e(__('lang.' . strtoupper('phone'))); ?></label>
                                                    <input type="text" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->phone); ?>">
                                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="customer_group" class="control-label"><?php echo e(__('lang.' . strtoupper('customer_group'))); ?></label>
                                                    <select name="customer_group" class="selectpicker <?php $__errorArgs = ['customer_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  data-width="100%" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>">
                                                        <option value=""></option>
                                                        <?php $__currentLoopData = $customer_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($customer_group->name_en); ?>" <?php echo e($customer_group->name_en == $user->customer_group ? 'selected' : ''); ?> ><?php echo e(__('lang.' . strtoupper(implode('_', explode(' ', $customer_group->name_en))))); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('customer_group')): ?>
                                                        <span class="help-block text-danger text-bold" role="alert">
                                                            <?php echo e($errors->first('customer_group')); ?>

                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="subscription_code" class="control-label"><?php echo e(__('lang.' . strtoupper('subscription_code'))); ?></label>
                                                    <input type="text" name="subscription_code" class="form-control <?php $__errorArgs = ['subscription_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->subscription_code); ?>">
                                                    <?php $__errorArgs = ['subscription_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>






                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="tax_number" class="control-label"><?php echo e(__('lang.' . strtoupper('tax_number'))); ?></label>
                                                    <input type="text" name="tax_number" class="form-control <?php $__errorArgs = ['tax_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user->tax_number); ?>">
                                                    <?php $__errorArgs = ['tax_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>




                                        </div>
                                        <hr class="bg-info">

                                        <div class="row">
                                            <div class="col-md-12">
                                                <strong><?php echo e(__('lang.' . strtoupper('billing_address'))); ?></strong>
                                                <hr class="bg-info">

                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="country" class="control-label ">
                                                                <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('Country'))); ?></span>
                                                            </label>
                                                            <select name="country" class="selectpicker <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true" required>
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($country->id); ?>" <?php echo e($user_addresses->country == $country->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $country->name_en : $country->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('country')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                    <?php echo e($errors->first('country')); ?>

                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="province" class="control-label">
                                                                <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('Province'))); ?></span>
                                                            </label>
                                                            <select name="province" class="selectpicker <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true" required>
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($province->id); ?>" <?php echo e($user_addresses->province == $province->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $province->name_en : $province->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('province')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                    <?php echo e($errors->first('province')); ?>

                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="county" class="control-label"><?php echo e(__('lang.' . strtoupper('County'))); ?></label>
                                                            <select name="county" class="selectpicker <?php $__errorArgs = ['county'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true">
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $counties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $county): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($county->id); ?>" <?php echo e($user_addresses->county == $county->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $county->name_en : $county->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('county')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                    <?php echo e($errors->first('county')); ?>

                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="section" class="control-label"><?php echo e(__('lang.' . strtoupper('Section'))); ?></label>
                                                            <select name="section" class="selectpicker <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true">
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($section->id); ?>" <?php echo e($user_addresses->section == $section->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $section->name_en : $section->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('section')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                    <?php echo e($errors->first('section')); ?>

                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="city" class="control-label"><?php echo e(__('lang.' . strtoupper('City'))); ?></label>
                                                            <select name="city" class="selectpicker <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true">
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($city->id); ?>" <?php echo e($user_addresses->city == $city->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $city->name_en : $city->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('city')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                    <?php echo e($errors->first('city')); ?>

                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="zip_code" class="control-label"><?php echo e(__('lang.' . strtoupper('ZIP_CODE'))); ?></label>
                                                            <input type="text" name="zip_code" class="form-control <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user_addresses->zip_code); ?>">
                                                            <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="longitude" class="control-label"><?php echo e(__('lang.' . strtoupper('Longitude'))); ?></label>
                                                            <input type="text" name="longitude" class="form-control <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user_addresses->longitude); ?>">
                                                            <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="latitude" class="control-label"><?php echo e(__('lang.' . strtoupper('Latitude'))); ?></label>
                                                            <input type="text" name="latitude" class="form-control <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($user_addresses->latitude); ?>">
                                                            <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="address" class="control-label"><?php echo e(__('lang.' . strtoupper('Address'))); ?></label>
                                                            <textarea name="address" cols="30" rows="7" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($user_addresses->address); ?></textarea>
                                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>













































































































































                                        </div>
                                        <hr class="bg-info">







                                        <div class="row">
                                            <div class="col-12">
                                                <a href="#" class="btn btn-secondary"><?php echo e(__('lang.' . strtoupper('Cancel'))); ?></a>
                                                <button type="submit" class="btn btn-success float-right add-payment-item"><?php echo e(__('lang.' . strtoupper('Submit'))); ?></button>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>

                        </div>
                        <!-- /.card-body -->
                    </div>

                    <div class="card card-info card-outline bills <?php echo e(((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == 'bills') || Session::get('level') == 'bills') ? '' : ((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == '') && Session::get('level') == '' ? '' : 'collapsed-card')); ?>">
                        <div class="card-header" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <h3 class="card-title"><?php echo e(__('lang.' . strtoupper('addresses'))); ?></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                                    <i class="fas fa-angle-double-<?php echo e(((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == 'bills') || Session::get('level') == 'bills') ? 'up' : ((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == '') && Session::get('level') == '' ? 'up' : 'down')); ?>"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <table class="widefat table table-striped text-center table-clients no-footer" data-table="data-table" id="">
                                        <thead>
                                        <tr>
                                            <th><?php echo e(__('lang.' . strtoupper('#'))); ?></th>
                                            <th><?php echo e(__('lang.' . strtoupper('name_or_company_name'))); ?></th>
                                            <th><?php echo e(__('lang.' . strtoupper('email'))); ?></th>
                                            <th><?php echo e(__('lang.' . strtoupper('mobile'))); ?></th>
                                            <th><?php echo e(__('lang.' . strtoupper('phone_number'))); ?></th>





                                        </tr>
                                        </thead>


                                        <tbody>
                                        <?php if($addresses && count($addresses) > 0): ?>
                                            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(++$key); ?></td>
                                                    <td>
                                                        <?php if(!in_array($user->roles->pluck('name')->first(), array('Super User', 'Management', 'Administrator'))
                                                        or (in_array($_auth->roles->pluck('name')->first(), array('Super User'))
                                                            and in_array($user->roles->pluck('name')->first(), array('Management', 'Administrator')))
                                                        or (in_array($_auth->roles->pluck('name')->first(), array('Management'))
                                                            and in_array($user->roles->pluck('name')->first(), array('Administrator')))
                                                        or ($user->id == $_auth->id)): ?>

                                                            <strong><?php echo e($address->first_name . ' ' . $address->last_name); ?></strong>
                                                        <?php else: ?>
                                                            <strong><?php echo e($address->first_name . ' ' . $address->last_name); ?></strong>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="email"><a href="mailto:<?php echo e($address->email); ?>"><?php echo e($address->email); ?></a></td>
                                                    <td><?php echo e($address->mobile); ?></td>
                                                    <td><?php echo e($address->phone_number); ?></td>

























































                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>



                                        <tfoot>
                                        <tr>
                                            <th><?php echo e(__('lang.' . strtoupper('#'))); ?></th>
                                            <th><?php echo e(__('lang.' . strtoupper('name_or_company_name'))); ?></th>
                                            <th><?php echo e(__('lang.' . strtoupper('email'))); ?></th>
                                            <th><?php echo e(__('lang.' . strtoupper('mobile'))); ?></th>
                                            <th><?php echo e(__('lang.' . strtoupper('phone_number'))); ?></th>





                                        </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>

                        </div>
                        <!-- /.card-body -->
                    </div>

                    <div class="card card-info card-outline add_bill <?php echo e(((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == 'add_bill') || Session::get('level') == 'add_bill') ? '' : ((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == '') && Session::get('level') == '' ? '' : 'collapsed-card')); ?>">
                        <div class="card-header" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <h3 class="card-title"><?php echo e(__('lang.' . strtoupper('add_address'))); ?></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                                    <i class="fas fa-angle-double-<?php echo e(((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == 'add_bill') || Session::get('level') == 'add_bill') ? 'up' : ((Session::get('_old_input') !== null and Session::get('_old_input')['form_level'] == '') && Session::get('level') == '' ? 'up' : 'down')); ?>"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">

                            <div class="row">
                                <div class="col-md-12">
                                    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" class="client-form" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="lead_id" value="0">

                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="marketer_id" class="control-label"><span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('Marketer'))); ?></span></label>
                                                    <select name="marketer_id" class="selectpicker <?php $__errorArgs = ['marketer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-width="100%" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" required>
                                                        <option value="0"><?php echo e(__('lang.' . strtoupper('no_marketer'))); ?></option>
                                                        <?php $__currentLoopData = $marketers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($marketer->id); ?>"><?php echo e($marketer->first_name . ' ' . $marketer->last_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('marketer_id')): ?>
                                                        <span class="help-block text-danger text-bold" role="alert">
                                                                    <?php echo e($errors->first('marketer_id')); ?>

                                                                </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            


                                        </div>
                                        <hr class="bg-info">

                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="first_name" class="control-label">
                                                        <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('first_name'))); ?></span>
                                                    </label>
                                                    <input type="text" name="first_name" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('first_name')); ?>" required>
                                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="last_name" class="control-label">
                                                        <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('last_name'))); ?></span>
                                                    </label>
                                                    <input type="text" id="last_name" name="last_name" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('last_name')); ?>" required>
                                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="email" class="control-label">
                                                        <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('email'))); ?></span>
                                                    </label>
                                                    <input type="email" id="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required>
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="mobile" class="control-label">
                                                        <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('Mobile'))); ?></span>
                                                    </label>
                                                    <input type="text" id="mobile" name="mobile" class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('mobile')); ?>" required>
                                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="phone" class="control-label"><?php echo e(__('lang.' . strtoupper('Phone'))); ?></label>
                                                    <input type="text" id="phone" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>">
                                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="customer_group" class="control-label"><?php echo e(__('lang.' . strtoupper('customer_group'))); ?></label>
                                                    <select name="customer_group" class="selectpicker <?php $__errorArgs = ['customer_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  data-width="100%" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>">
                                                        <option value=""></option>
                                                        <?php $__currentLoopData = $customer_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($customer_group->name_en); ?>" <?php echo e($customer_group->name_en == old('customer_group') ? 'selected' : ''); ?> ><?php echo e(__('lang.' . strtoupper(implode('_', explode(' ', $customer_group->name_en))))); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('customer_group')): ?>
                                                        <span class="help-block text-danger text-bold" role="alert">
                                                                    <?php echo e($errors->first('customer_group')); ?>

                                                                </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="subscription_code" class="control-label"><?php echo e(__('lang.' . strtoupper('subscription_code'))); ?></label>
                                                    <input type="text" id="subscription_code" name="subscription_code" class="form-control <?php $__errorArgs = ['subscription_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-fieldto="customers" data-fieldid="13" value="<?php echo e(old('subscription_code')); ?>">
                                                    <?php $__errorArgs = ['subscription_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>




                                            

                                            

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="tax_number" class="control-label"><?php echo e(__('lang.' . strtoupper('Tax_Number'))); ?></label>
                                                    <input type="text" id="tax_number" name="tax_number" class="form-control <?php $__errorArgs = ['tax_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('tax_number')); ?>">
                                                    <?php $__errorArgs = ['tax_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                        </div>
                                        <hr class="bg-info">

                                        <div class="row">

                                            <div class="col-md-12">
                                                <strong><?php echo e(__('lang.' . strtoupper('billing_address'))); ?></strong>
                                                <hr class="bg-info">

                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="country" class="control-label ">
                                                                <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('Country'))); ?></span>
                                                            </label>
                                                            <select id="country" name="country" class="selectpicker <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true" required>
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($country->id); ?>" <?php echo e(old('country') == $country->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $country->name_en : $country->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('country')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                            <?php echo e($errors->first('country')); ?>

                                                                        </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="province" class="control-label">
                                                                <span class="req text-danger">* <?php echo e(__('lang.' . strtoupper('Province'))); ?></span>
                                                            </label>
                                                            <select id="province" name="province" class="selectpicker <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true" required>
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($province->id); ?>" <?php echo e(old('province') == $province->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $province->name_en : $province->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('province')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                            <?php echo e($errors->first('province')); ?>

                                                                        </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="county" class="control-label"><?php echo e(__('lang.' . strtoupper('County'))); ?></label>
                                                            <select id="county" name="county" class="selectpicker <?php $__errorArgs = ['county'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true">
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $counties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $county): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($county->id); ?>" <?php echo e(old('county') == $county->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $county->name_en : $county->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('county')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                            <?php echo e($errors->first('county')); ?>

                                                                        </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="section" class="control-label"><?php echo e(__('lang.' . strtoupper('Section'))); ?></label>
                                                            <select id="section" name="section" class="selectpicker <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true">
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($section->id); ?>" <?php echo e(old('section') == $section->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $section->name_en : $section->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('section')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                            <?php echo e($errors->first('section')); ?>

                                                                        </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="city" class="control-label"><?php echo e(__('lang.' . strtoupper('City'))); ?></label>
                                                            <select id="city" name="city" class="selectpicker <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="<?php echo e(__('lang.' . strtoupper('no_selected_item'))); ?>" data-width="100%" data-live-search="true">
                                                                <option value=""></option>
                                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($city->id); ?>" <?php echo e(old('city') == $city->id ? 'selected' : ''); ?>><?php echo e(app()->getLocale() == 'en' ? $city->name_en : $city->name_fa); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php if($errors->has('city')): ?>
                                                                <span class="help-block text-danger text-bold" role="alert">
                                                                            <?php echo e($errors->first('city')); ?>

                                                                        </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="zip_code" class="control-label"><?php echo e(__('lang.' . strtoupper('ZIP_CODE'))); ?></label>
                                                            <input type="text" id="zip_code" name="zip_code" class="form-control <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('zip_code')); ?>">
                                                            <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="longitude" class="control-label"><?php echo e(__('lang.' . strtoupper('Longitude'))); ?></label>
                                                            <input type="text" id="longitude" name="longitude" class="form-control <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('longitude')); ?>">
                                                            <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label for="latitude" class="control-label"><?php echo e(__('lang.' . strtoupper('Latitude'))); ?></label>
                                                            <input type="text" id="latitude" name="latitude" class="form-control <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('latitude')); ?>">
                                                            <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="address" class="control-label"><?php echo e(__('lang.' . strtoupper('Address'))); ?></label>
                                                            <textarea name="address" id="address" cols="30" rows="7" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('address')); ?></textarea>
                                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            
                                            

                                        </div>
                                        <hr class="bg-info">

                                        
                                        
                                        
                                        
                                        

                                        <div class="row">
                                            <div class="col-12">
                                                <a href="#" class="btn btn-secondary"><?php echo e(__('lang.' . strtoupper('Cancel'))); ?></a>
                                                <button type="submit" class="btn btn-success float-right add-payment-item"><?php echo e(__('lang.' . strtoupper('Submit'))); ?></button>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>


                            































































































































































































































































































































































































































































                        </div>
                        <!-- /.card-body -->
                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\server-new-tab\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>