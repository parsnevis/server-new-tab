<div class="row">
    <div class="col-sm-12">
        <table class="widefat table table-striped text-center table-clients no-footer">
            <thead>
            <tr>
                <th class="id"><?php echo e(__('lang.' . strtoupper('#'))); ?></th>
                <th class="name"><?php echo e(__('lang.' . strtoupper('name_or_company_name'))); ?></th>
                <th class="email"><?php echo e(__('lang.' . strtoupper('email'))); ?></th>
                <th class="phone"><?php echo e(__('lang.' . strtoupper('phone_number'))); ?></th>
                <th class="group"><?php echo e(__('lang.' . strtoupper('activated'))); ?></th>
                <th class="group"><?php echo e(__('lang.' . strtoupper('customer_group'))); ?></th>

                <th class="group"><?php echo e(__('lang.' . strtoupper('subscription_code'))); ?></th>
                <th class="operation"><?php echo e(__('lang.' . strtoupper('operations'))); ?></th>
            </tr>
            </thead>

            <tbody>
            <?php if($users && count($users) > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><span class="persian-number"><?php echo e(($key+1)+($page == 1 ? 0 : ($page-1)*15)); ?></span></td>
                        <td>
                            <?php if(!in_array($user->roles->pluck('name')->first(), array('Super User', 'Management', 'Administrator'))
                            or (in_array($_auth->roles->pluck('name')->first(), array('Super User'))
                                and in_array($user->roles->pluck('name')->first(), array('Management', 'Administrator')))
                            or (in_array($_auth->roles->pluck('name')->first(), array('Management'))
                                and in_array($user->roles->pluck('name')->first(), array('Administrator')))
                            or ($user->id == $_auth->id)): ?>
                                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"><strong><?php echo e($user->first_name . ' ' . $user->last_name); ?></strong></a>
                            <?php else: ?>
                                <strong><?php echo e($user->first_name . ' ' . $user->last_name); ?></strong>
                            <?php endif; ?>
                        </td>
                        <td class="email"><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
                        <td><?php echo e($user->phone_number); ?></td>
                        <td>
                            <?php if(!in_array($user->roles->pluck('name')->first(), array('Super User', 'Management', 'Administrator'))
                            or (in_array($_auth->roles->pluck('name')->first(), array('Super User'))
                                and in_array($user->roles->pluck('name')->first(), array('Management', 'Administrator')))
                            or (in_array($_auth->roles->pluck('name')->first(), array('Management'))
                                and in_array($user->roles->pluck('name')->first(), array('Administrator')))): ?>

                                <div class="onoffswitch">
                                    <input type="checkbox" name="customer_status" class="onoffswitch-checkbox" id="customer-<?php echo e($user->id); ?>" <?php echo e($user->activated == 'Yes' ? 'checked' : ''); ?>>
                                    <label class="onoffswitch-label" for="customer-<?php echo e($user->id); ?>"></label>
                                </div>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(empty($user->customer_group) || $user->customer_group == null): ?>
                                <span class="label label-info mleft5 inline-block"><?php echo e(__('lang.' . strtoupper("doesn't_have"))); ?></span>
                            <?php else: ?>
                                <?php $__currentLoopData = $customer_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($customer_group->name_en == $user->customer_group): ?>
                                        <span class="label label-info mleft5 inline-block"><?php echo e(__('lang.' . strtoupper(implode('_', explode(' ', $customer_group->name_en))))); ?></span>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>

                        <td><span><?php echo e($user->subscribtion_code); ?></span></td>
                        <td>
                            <div>
                                <form action="<?php echo e(route('admin.users.destroy',$user->id)); ?>" method="POST">
                                    <div class="btn-group">
                                        <?php if(!in_array($user->roles->pluck('name')->first(), array('Super User', 'Management', 'Administrator'))
                                        or (in_array($_auth->roles->pluck('name')->first(), array('Super User'))
                                            and in_array($user->roles->pluck('name')->first(), array('Management', 'Administrator')))
                                        or (in_array($_auth->roles->pluck('name')->first(), array('Management'))
                                            and in_array($user->roles->pluck('name')->first(), array('Administrator')))
                                        or ($user->id == $_auth->id)): ?>

                                            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-info"><i class="fas fa-edit"></i></a>
                                            <a href="<?php echo e(route('admin.users.reset', $user->id)); ?>" class="btn btn-warning"><i class="fas fa-user-edit"></i></a>
                                            <a href="<?php echo e(route('admin.users.login', $user->id)); ?>" target="_blank" class="btn btn-warning"><i class="fas fa-user-lock"></i></a>
                                        <?php endif; ?>

                                        <?php if(!in_array($user->roles->pluck('name')->first(), array('Super User', 'Management', 'Administrator'))
                                        or (in_array($_auth->roles->pluck('name')->first(), array('Super User'))
                                            and in_array($user->roles->pluck('name')->first(), array('Management', 'Administrator')))
                                        or (in_array($_auth->roles->pluck('name')->first(), array('Management'))
                                            and in_array($user->roles->pluck('name')->first(), array('Administrator')))): ?>

                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('آیا از حذف این آیتم مطمئن هستید؟');" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>

                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>

            <tfoot>
            <tr>
                <th class="id"><?php echo e(__('lang.' . strtoupper('#'))); ?></th>
                <th class="name"><?php echo e(__('lang.' . strtoupper('name_or_company_name'))); ?></th>
                <th class="email"><?php echo e(__('lang.' . strtoupper('email'))); ?></th>
                <th class="phone"><?php echo e(__('lang.' . strtoupper('phone_number'))); ?></th>
                <th class="group"><?php echo e(__('lang.' . strtoupper('activated'))); ?></th>
                <th class="group"><?php echo e(__('lang.' . strtoupper('customer_group'))); ?></th>

                <th class="group"><?php echo e(__('lang.' . strtoupper('subscription_code'))); ?></th>
                <th class="operation"><?php echo e(__('lang.' . strtoupper('operations'))); ?></th>
            </tr>
            </tfoot>
        </table>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php /**PATH D:\laragon\www\server-new-tab\resources\views/admin/users/data_table.blade.php ENDPATH**/ ?>