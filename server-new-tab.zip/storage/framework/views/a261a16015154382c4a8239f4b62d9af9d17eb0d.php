<html lang="<?php echo e($_auth->default_language); ?>">
<?php
use \App\Http\Controllers\RequireFunction;

$getRoute = RequireFunction::getRoute();
$route = @$getRoute[0];
$action = @$getRoute[1];

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{--><!--{ csrf_token() }}">


    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/fontawesome.min.css')); ?>">

    <!-- Ionicons -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/ionicons.min.css')); ?>">
    <!-- Tempusdominus Bbootstrap 4 -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/tempusdominus-bootstrap-4.min.css')); ?>">
    <!-- iCheck -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/icheck-bootstrap.min.css')); ?>">
    <!-- JQVMap -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/jqvmap.min.css')); ?>">

    <?php if($_auth->default_language == 'en'): ?>
    <!-- Bootstrap 4 -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">

    <?php elseif($_auth->default_language == 'fa' || $_auth->default_language == 'ar'): ?>
    <!-- Bootstrap 4 RTL -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/bootstrap-rtl.min.css')); ?>">
    <?php endif; ?>

<!-- Theme style -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/admintheme.css')); ?>">


    <!-- overlayScrollbars -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/OverlayScrollbars.min.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/daterangepicker.css')); ?>">
    <!-- summernote -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/summernote-bs4.css')); ?>">


    <!-- dataTables -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/datatables.min.css')); ?>">
    <!-- select2 -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/select2-bootstrap4.min.css')); ?>">


    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/fonts.css')); ?>">
    <!-- Custom style for Backend -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/backend-custom.css')); ?>">

    <!-- Toastr -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>">

    <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/persian-datepicker.min.css')); ?>">
    <?php if($_auth->default_language == 'fa' || $_auth->default_language == 'ar'): ?>
    <!-- Bootstrap 4 RTL -->

    <!-- Persian Date picker for RTL -->


        <!-- Custom style for RTL -->
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/custom-rtl.css')); ?>">
    <!-- Custom fonts for RTL -->
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/css/fonts-persian.css')); ?>">
    <?php endif; ?>

    <!-- jQuery -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script type="text/javascript">
        $.widget.bridge('uibutton', $.ui.button)
    </script>



        <!-- Persian Date picker for RTL -->

            <script type="text/javascript" src="<?php echo e(asset('assets/js/persian-date.min.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(asset('assets/js/persian-datepicker.min.js')); ?>"></script>


<!-- Popper -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed sidebar-collapse">
<?php
//\Illuminate\Support\Facades\App::setLocale($_auth->default_language);
//dd($_auth);
?>

<input type="hidden" name="default_laguage" value="{--><!--{ $_auth->default_language }}">

<div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
            </li>






        </ul>

        <!-- SEARCH FORM -->
        <form class="form-inline">
            <div class="input-group input-group-sm">
                <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-navbar" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </form>

        <!-- Right navbar links -->
        <ul class="navbar-nav mr-auto-navbav">
            <li><strong>میزان شارژ: </strong><span><?php echo e($_auth->charge); ?></span></li>
        </ul>
        <ul class="navbar-nav mr-auto-navbav">
            <!-- Messages Dropdown Menu -->

































































































            <li class="nav-item calendar-box">
                <div class="clock-box">
                    <div class="float-right" id="clock"></div>
                </div>
            </li>
            <li class="nav-item calendar-box">
                <div class="persian-date-box">
                    <div class="progress-description"><?php echo e(jdate()->format('l - d F Y')); ?></div>
                </div>
            </li>
            <li class="nav-item calendar-box">
                <div class="gregorian-date-box">
                    <div class="gregorian-date"><?php echo e(date('D - Y d M')); ?></div>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link text-danger" data-widget="control-sidebar" data-slide="true"  href="<?php echo e(route('reseller.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fas fa-power-off" alt="<?php echo e(__('lang.' . strtoupper('Logout'))); ?>"></i>
                </a>
            </li>
        </ul>
        <script language="JavaScript">

            var myVar = setInterval(showTheTime, 1000);

            function showTheHours(theHour) {
                if (theHour > 0 && theHour < 13) {
                    if (theHour == "0") theHour = 12;
                    return (theHour);
                }
                if (theHour == 0) {
                    return (12);
                }
                return (theHour-12);
            }
            function showZeroFilled(inValue) {
                if (inValue > 9) {
                    return "" + inValue;
                }
                return "0" + inValue;
            }
            function showTheTime() {
                now = new Date(<?php date('Y-m-d H:i:s') ?>);

                document.getElementById("clock").innerHTML = showTheHours(now.getHours()) + ":" + showZeroFilled(now.getMinutes()) + ":" + showZeroFilled(now.getSeconds());
                // setTimeout("showTheTime()",1000)
            }

        </script>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="/" class="brand-link">



        </a>

        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Sidebar user panel (optional) -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <div class="image">
                    <img src="<?php echo e(asset($_auth->profile_picture)); ?>" class="img-circle elevation-2" alt="User Image">
                </div>
                <div class="info">
                    <a href="<?php echo e(route('reseller.profile')); ?>" class="d-block"><?php echo e(!empty($_auth->nice_name) ? $_auth->nice_name : $_auth->first_name . ' ' . $_auth->last_name); ?></a>
                    <span class="label label-administrator"><?php echo e(__('lang.' . strtoupper(implode('_', explode(' ', $_auth->roles->pluck('name')->first()))))); ?></span>
                </div>
                <div class="info float-right">
                    <a class="text-danger" href="<?php echo e(route('reseller.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fas fa-power-off" alt="<?php echo e(__('lang.' . strtoupper('Logout'))); ?>"></i>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('reseller.logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>































































































            <!-- Date and Time -->
            <div class="row">
                <div class="col-12">












































                </div>
            </div>
            <!-- ./Date and Time -->

            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    <!-- Add icons to the links using the .nav-icon class
                         with font-awesome or any other icon font library -->

                    <!-- Dashboard Menu -->
                    <li class="nav-item <?php echo e($route == 'console' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('reseller.dashboard')); ?>" class="nav-link <?php echo e($route == 'console' ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p><?php echo e(__('lang.' . strtoupper('console'))); ?></p>
                        </a>
                    </li>



                    <!-- Users Menu -->

                        <li class="nav-item has-treeview <?php echo e(($route == 'users' or $route == 'user') ? 'menu-open' : ''); ?>">
                            <a href="#" class="nav-link <?php echo e(($route == 'users' or $route == 'user') ? 'active' : ''); ?>">
                                <i class="nav-icon fas fa-user-alt"></i>
                                <p><?php echo e(__('lang.' . strtoupper('Users'))); ?><i class="right fas fa-angle-left"></i></p>
                            </a>
                            <ul class="nav nav-treeview">

                                    <li class="nav-item">
                                        <a href="<?php echo e(Route('reseller.users.index')); ?>" class="nav-link <?php echo e($route == 'users' && $action == 'index' ? 'active' : ''); ?>">
                                            <i class="nav-icon fas fa-users"></i>
                                            <p><?php echo e(__('lang.' . strtoupper('all_users'))); ?></p>
                                        </a>
                                    </li>


                                    <li class="nav-item">
                                        <a href="<?php echo e(Route('reseller.users.create')); ?>" class="nav-link <?php echo e($route == 'users' && $action == 'create' ? 'active' : ''); ?>">
                                            <i class="nav-icon fas fa-user-plus"></i>
                                            <p><?php echo e(__('lang.' . strtoupper('CREATE_USER'))); ?></p>
                                        </a>
                                    </li>

                            </ul>
                        </li>
















































































                </ul>
                <br><br>
            </nav>

            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">


                    </div><!-- /.col -->






                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <?php echo $__env->yieldContent('content'); ?>

        <div class="row">
            <div class="col-12">
                <br><br><br>
                <br><br><br>
            </div>
        </div>

        <a id="back-to-top" href="#" class="btn btn-primary back-to-top" role="button" aria-label="Scroll to top">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- /.content-wrapper -->

    <?php echo $__env->yieldContent('modal'); ?>



    <footer class="main-footer no-print">

        <div class="row">
            <div class="col-6">

                <div class="d-sm-inline-block">
                    <?php if(app()->getLocale() == 'en'): ?>
                        <span><?php echo e(jdate()->toCarbon()->format('Y')); ?> - <?php echo e(jdate()->toCarbon()->addYears(5)->format('Y')); ?> &copy;</span>
                    <?php else: ?>
                        <span><?php echo e(jdate()->getYear()); ?> - <?php echo e(jdate()->addYears(5)->getYear()); ?> &copy;</span>
                    <?php endif; ?>
                    <strong><?php echo __('lang.' . strtoupper('COPYRIGHT_STATEMENT')); ?></strong>
                </div>
            </div>

            <div class="col-6">
                <div class="d-sm-inline-block float-right">
                    <strong><?php echo e(__('lang.' . strtoupper('ONLINE_INTERNATIONAL_TRANSPORTATION_SYSTEM'))); ?> , </strong>

                </div>
            </div>
        </div>
    </footer>
</div>
<!-- ./wrapper -->



<!-- Bootstrap 4 rtl -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap-rtl.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- ChartJS -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/Chart.min.js')); ?>"></script>
<!-- Sparkline -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/sparkline.js')); ?>"></script>
<!-- JQVMap -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.vmap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.vmap.world.js')); ?>"></script>
<!-- jQuery Knob Chart -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.knob.min.js')); ?>"></script>
<!-- daterangepicker -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/daterangepicker.js')); ?>"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
<!-- Summernote -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/summernote-bs4.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.overlayScrollbars.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/adminlte.min.js')); ?>"></script>


<!-- dataTables -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/datatables.min.js')); ?>"></script>
<!-- select2 -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/select2.full.min.js')); ?>"></script>
<!-- Toastr -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/toastr.min.js')); ?>"></script>
<!-- TreeView Js -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/tree.min.js')); ?>"></script>


<!-- Custom js for Backend -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.ajax.queue.coffee')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.ajax.queue.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/backend-custom.js')); ?>"></script>




<!-- AdminLTE dashboard demo (This is only for demo purposes) -->

<!-- AdminLTE for demo purposes -->


    <script type="text/javascript">
        toastr.options = {
            "closeButton": false,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-<?php echo $_auth->default_language == 'en' ? 'right' : 'left' ?>",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };

        var info = "<?php echo $_auth->default_language == 'en' ? Session::get('info') : __('lang.' . strtoupper('' . Session::get('info'))); ?>";
        var success = "<?php echo $_auth->default_language == 'en' ? Session::get('success') : __('lang.' . strtoupper('' . Session::get('success'))); ?>";
        var warning = "<?php echo $_auth->default_language == 'en' ? Session::get('warning') : __('lang.' . strtoupper('' . Session::get('warning'))); ?>";
        var error = "<?php echo $_auth->default_language == 'en' ? Session::get('error') : __('lang.' . strtoupper('' . Session::get('error'))); ?>";


        <?php if(Session::get('info')): ?>
        toastr.info(info);
        <?php elseif(Session::get('success')): ?>
        toastr.success(success);
        <?php elseif(Session::get('warning')): ?>
        toastr.warning(warning);
        <?php elseif(Session::get('error')): ?>
        toastr.error(error);//.css("width","auto");
        <?php endif; ?>
    </script>

    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\server-new-tab\resources\views/reseller/layouts/reseller.blade.php ENDPATH**/ ?>