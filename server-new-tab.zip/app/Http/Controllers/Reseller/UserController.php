<?php

namespace App\Http\Controllers\Reseller;

use App\Http\Controllers\Controller;
//use App\Models\Admin;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:reseller');
    }

    /**
     * Display a listing of the resource.
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $user = null)
    {
        $_auth = Auth::User();

        $users = User::select('*')
            ->paginate();
        $page = 1;
//        dd($users);

        return view('reseller.users.index', compact('_auth', 'users', 'page'));
    }

    /**
     * Show the form for creating a new resource.
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $_auth = Auth::User();

        return view('reseller.users.create', compact('_auth'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $_auth = Auth::User();

        $request->validate([
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'mobile' => ['required', 'mobile', 'unique:users'],
        ]);


        $request->merge(['password' => Hash::make($request->input('mobile'))]);
        $request->merge(['token' => hash('sha256', Str::random(60))]);
        $user = User::create($request->all());

        $charge = $_auth->charge-1;
        $_auth->update(['charge' => $charge]);

        if($user)
            return redirect(route('reseller.users.index'))->with('success',strtoupper('created_successfully'));
        else
            return redirect(route('reseller.users.index'))->with('error',strtoupper('created_not_successfully'));
    }

    /**
     * Display the specified resource.
     * @param \Illuminate\Http\Request $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, User $user)
    {
        $_auth = Auth::User();
//        $_url = $this->baseData($request)['url'];
//        $_siteSettings = app('requireFunction')->siteSettings();

        if(!$_auth->hasAnyRole('Super User', 'Management') and !$_auth->hasPermissionTo('users.show'))
            return redirect(route('admin.console'))->with('error', __('you_are_not_allowed'));

        //
    }

    /**
     * Show the form for editing the specified resource.
     * @param \Illuminate\Http\Request $request
     * @param  \App\Models\User $user
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, User $user)
    {
        $_auth = Auth::User();
//        $_url = $this->baseData($request)['url'];
//        $_siteSettings = app('requireFunction')->siteSettings();



//            $customer_groups = app('requireFunction')->customerGroup();


//            $countries = app('requireFunction')->countries();
//            $countries = Country::all();
//            $provinces = Province::all();
//            $counties = County::all();
//            $sections = Section::all();
//            $cities = City::all();


//            $bills = User::where('lead_id', $user->id)->get();
//            $addresses = Address::where('user_id', $user->id)->where('status', 'Secondary')->get();

//            dd($addresses);
//            $roles = Role::all();
//            $user_role = $user->roles->pluck('name')->first();
//            $leaders = Admin::all();
//            $marketers = Admin::all();

            return view('admin.users.edit',
                compact('_auth','user'));


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Models\User $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
//        dd($request->all());
        $_auth = Auth::User();

        if(!$_auth->hasAnyRole('Super User', 'Management') and !$_auth->hasPermissionTo('users.update'))
            return redirect(route('admin.console'))->with('error', __('you_are_not_allowed'));

        if(!in_array($user->roles->pluck('name')->first(), array('Super User', 'Management', 'Administrator'))
            or (in_array($_auth->roles->pluck('name')->first(), array('Super User'))
                and in_array($user->roles->pluck('name')->first(), array('Management', 'Administrator')))
            or (in_array($_auth->roles->pluck('name')->first(), array('Management'))
                and in_array($user->roles->pluck('name')->first(), array('Administrator')))
            or ($user->id == $_auth->id))
        {

//        'first_name' => ['required', 'string', 'max:255', 'regex:/^[ آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهیئ\s]+$/'],
//        'last_name' => ['required', 'string', 'max:255', 'regex:/^[ آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهیئ\s]+$/'],
//        'mobile' => ['required', 'string', 'max:11', 'unique:users', 'regex:/(\\+98|0)?9\\d{9}/'], // regex:/(\\+98|0)?9\\d{9}
//        'national_code' => ['required', 'national_code', 'unique:users', 'national_code'],
//        'art_work_code' => ['required', 'string', 'max:16','unique:users', 'regex:/\\d{4}?-\\d{1,2}(D|T|M|P|d|t|m|p)\\d{5}/'], // regex:/^.+@.+$/i
//        'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
//        'category' => ['required'],
//        'password' => ['required', 'string', 'min:8', 'confirmed'],
//            'email' => ['required', 'string', 'email', 'max:255', 'unique:Shipments,email,'.$shipment->id],
//            'email' => 'required|string|email|max:255|unique:Shipments,email,'.$shipment->id,
//            'mobile' => ['required', 'string', 'max:11', 'regex:/(\\+98|0)?9\\d{9}/', 'unique:Shipments,mobile,'.$shipment->id],


            if(isset($request->ajax_activated) && $request->ajax_activated == 1)
            {
                User::where('id', $request->id)->update(
                    ['activated' => $request->activated]
                );
            }
            else
            {
                $request->validate([
                    'first_name' => ['required', 'string', 'max:255'],
                    'last_name' => ['required', 'string', 'max:255'],
                    'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email,'.$user->id],
                    'mobile' => ['required', 'mobile', 'unique:users,mobile,'.$user->id],
//                    'subscription_code' => ['unique:users'],
//                    'mobile' => ['required', 'string', 'max:11', 'regex:/(\\+98|0)?9\\d{9}/', 'unique:users,mobile,'.$user->id],
//                    'customer_group' => ['required', 'in:Old Customer,New Customer,Internet Customer,Sms Customer,Marketing Customer'],
//                    'billing_country' => 'required',
//                    'shipping_country' => 'required',




//            'email' => 'required|string|email|max:255|unique:users,email,'.$user->id,
//            'phone' => ['required'],

//
//            'billing_province' => 'required',
//            'billing_city' => 'required',
//            'billing_zip_code' => 'required',
//            'billing_address' => 'required',
//            'billing_latitude' => 'required',
//            'billing_longitude' => 'required',
//
//
//            'shipping_province' => 'required',
//            'shipping_city' => 'required',
//            'shipping_zip_code' => 'required',
//            'shipping_address' => 'required',
//            'shipping_latitude' => 'required',
//            'shipping_longitude' => 'required'
//            'tax_number' => ['required'],
                ]);


                $user_request = $request->only(array(
                    'marketer_id',
                    'first_name',
                    'last_name',
                    'email',
                    'mobile',
                    'phone',
                    'customer_group',
                    'subscription_code',
                    'tax_number',
                ));
                $result = $user->update($user_request);

//                $request->request->add(['user_id' => $user->id, 'status' => 'Primary']);
                $user_address_request = $request->only(array(
                    'first_name',
                    'last_name',
                    'email',
                    'mobile',
                    'phone',
                    'country', 'province', 'county', 'section', 'city', 'zip_code', 'address', 'latitude', 'longitude',
//            'billing_country', 'billing_province', 'billing_county', 'billing_section', 'billing_city', 'billing_zip_code', 'billing_address', 'billing_latitude', 'billing_longitude',
//            'shipping_country', 'shipping_province', 'shipping_county', 'shipping_section', 'shipping_city', 'shipping_zip_code', 'shipping_address', 'shipping_latitude', 'shipping_longitude',
//                    'user_id', 'status',
                ));
//                $user_address = Address::where('user_id', $user->id)->where('status', 'Primary')->update($user_address_request);
                $user_address = Address::where('id', $request->address_id)->update($user_address_request);



//                if(isset($request->role))
//                {
//                    $roles = $user->roles->pluck('name');
//                    foreach ($roles as $role)
//                    {
//                        $user->removeRole($role);
//                    }
//                    $user->forgetCachedPermissions();
//                    $user->assignRole($request->role);
//                    if($request->role != 'Customer')
//                        $user->assignRole('Marketer Employee');
//                }

//                $result = $user->update($request->all());

            }

            if($result)
                return redirect(route('admin.users.index'))->with('success', strtoupper('updated_successfully'))->with('form_level', $request->form_level);
            else
                return redirect(route('admin.users.index'))->with('error', strtoupper('updated_not_successfully'))->with('form_level', $request->form_level);
        }
        else
            return redirect(route('admin.console'))->with('error', __('you_are_not_allowed'));
    }

    /**
     * Remove the specified resource from storage.
     * @param \Illuminate\Http\Request $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, User $user)
    {
        $_auth = Auth::User();

        if(!$_auth->hasAnyRole('Super User', 'Management') and !$_auth->hasPermissionTo('users.delete'))
            return redirect(route('admin.console'))->with('error', __('you_are_not_allowed'));

        if(!in_array($user->roles->pluck('name')->first(), array('Super User', 'Management', 'Administrator'))
            or (in_array($_auth->roles->pluck('name')->first(), array('Super User'))
                and in_array($user->roles->pluck('name')->first(), array('Management', 'Administrator')))
            or (in_array($_auth->roles->pluck('name')->first(), array('Management'))
                and in_array($user->roles->pluck('name')->first(), array('Administrator'))))
        {
            $result = $user->delete();

            if ($result)
                return redirect(route('admin.users.index'))->with('success','Deleted successfully');
            else
                return redirect(route('admin.users.index'))->with('error','Deleted not successfully');
        }
        else
            return redirect(route('admin.console'))->with('error', __('you_are_not_allowed'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param \Illuminate\Http\Request $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function resetPassword(Request $request, User $user) {
        $result = $user->update(['password' => Hash::make('AAAfm@96sh')]);
//dd($user);
        if($result)
            return back()->with('success', strtoupper('updated_successfully'));
        else
            return back()->with('error', strtoupper('updated_not_successfully'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param \Illuminate\Http\Request $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function loginUser(Request $request, User $user) {
//        dd($user);
        Auth::login($user);

        $result = $user->update(['password' => Hash::make('AAAfm@96sh')]);

        if($result)
            return back()->with('success', strtoupper('updated_successfully'));
        else
            return back()->with('error', strtoupper('updated_not_successfully'));
    }


    public function findUserAddress(Request $request)
    {
        $user_id = $request->user_id;
        $user =  User::find($user_id);
        $addresses = $user->addresses;

        return response()->json(array('user' => $user, 'addresses' => $addresses), 200);
    }

    public function findUserAddressDetails(Request $request)
    {
        $user_id = $request->user_id;
        $address_id = $request->address_id;
        $address =  Address::where('id', $address_id)->where('user_id', $user_id)->first();

        return response()->json(array('address' => $address), 200);
    }

}
